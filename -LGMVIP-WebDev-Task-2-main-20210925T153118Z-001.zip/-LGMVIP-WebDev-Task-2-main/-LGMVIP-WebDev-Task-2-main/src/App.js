import './App.css';
import {Allusers,users}  from './Components/Allusers';


function App() {
  return (
    <div className="App">
       <Allusers />
    </div>
  );
}

export default App;
